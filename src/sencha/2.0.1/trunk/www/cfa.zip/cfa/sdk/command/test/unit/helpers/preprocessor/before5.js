//<deprecated>
var whatever = true;
//</deprecated>
