//<feature foo>
var foo;
//</feature>
//<feature bar>
var bar;
//</feature>

