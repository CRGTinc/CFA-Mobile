Ext.define('cfa.controller.phone.Dashboard', {
    extend: 'cfa.controller.Dashboard',

    config: {

    },

    init: function() {
        this.callParent();        
    }
});
