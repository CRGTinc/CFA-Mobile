Ext.define('cfa.controller.contact.ContactController',{
	extend: 'Ext.app.Controller',
	requires: ['cfa.view.contact.ContactView'],
	
	config: {
        routes: {
            'contacts': 'showContactPage'
        },

        refs: {
            main: 'main',
			contactContainer : 'contact_view_container',
			contactDetailView :  'contact_detail'
        },
		
		control:{
			contactContainer:{
				contactDetailCommand : 'displayContactDetail',
				reloadContactCommand : 'reloadContact',
			}			
		}
    },
	
	displayContactDetail: function(list,record){		
		var contactDetail = this.getContactDetailView();
		contactDetail.setRecord(record);
	},
	
	reloadContact: function(obj){
		obj.getContactStore().load();
		var store = obj.getContactStore();
		var jsonString = '';
		var jsonArray = [];
		store.each(function(rec){
			jsonString = rec.getData();
			jsonArray.push(jsonString);		
		});
				
		this.exportData(Ext.JSON.encode(jsonArray))
		
					
	},
	
	showContactPage: function(){
		var contactView = Ext.create('cfa.view.contact.ContactView');
		this.getMain().push(contactView);        						
	},
	
	
	gotFS: function(fileSystem) {
        fileSystem.root.getFile("readme.txt", {create: true, exclusive: false}, 
			function(fileEntry) {
        		fileEntry.createWriter(
        			function(writer) {
        				writer.onwrite = function(evt) {
            					console.log("write success");
        				};
        				writer.write(jsonString);
        			}
        			
        			, this.fail);
    		}
    	, this.fail);
    },
    
    exportData: function(jsonString) {
    	window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, 
	    		function(fileSystem) {
	        		fileSystem.root.getFile("readme.txt", {create: true, exclusive: false}, 
						function(fileEntry) {
			        		fileEntry.createWriter(
			        			function(writer) {
			        				writer.onwrite = function(evt) {
			            					console.log("write success");
			        				};
			        				writer.write(jsonString);
			        			}, this.fail);
			    		}, this.fail);
	    		},this.fail);	
   },

    

    

    fail: function(evt) {
        console.log(evt.target.error.code);
    }

})