Ext.define('cfa.controller.tablet.Dashboard', {
    extend: 'cfa.controller.Dashboard',

    config: {
        
    },

    init: function() {
        this.callParent();        
    },    
});
