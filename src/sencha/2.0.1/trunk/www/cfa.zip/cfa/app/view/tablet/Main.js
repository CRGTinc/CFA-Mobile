Ext.define('cfa.view.tablet.Main', {
    extend: 'cfa.view.Main'
});
