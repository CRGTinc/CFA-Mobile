Ext.define("cfa.view.case.CaseView", {
    extend: 'Ext.Container',
    xtype: 'case',

    config: {
        title: 'Case Data Management',
        layout: 'hbox',
        items: [{
                xtype: 'tabpanel',
                tabBarPosition: 'bottom',
                flex: 1,
                items: [{
                        xtype: 'nestedlist',
                        title: 'Cases',
                        iconCls: 'star',
                        id: 'caseslist',
                        store: 'Cases',
                        toolbar: {
                            items: [{
                                    xtype: 'button',
                                    iconCls: 'add',
                                    iconMask: true,
                                    align:'right',
                                    action: 'addCaseData'
                                }
                            ]
                        }
                    }, {
                        xtype: 'list',
                        title: 'Devices',
                        iconCls: 'settings'
                    }, {
                        xtype: 'panel',
                        title: 'Search',
                        iconCls: 'search'
                    }
                ]
            }, {
                xtype: 'panel',
                flex:2,
                layout: 'fit',
                items: [
                    {
                        xtype:'panel',
                        layout: 'vbox',                       
                        items:[
                            {
                                xtype: 'formpanel',
                                baseCls: 'panel-shadow',
                                cls:['infoPanel'],
                                
                                id: 'casecontextpanel',
                                layout: 'fit',
                                items:[{
                                	xtype:'label',
                                }],
                                flex: 1,
                            }, {
                                xtype: 'panel',
                                baseCls: 'panel-shadow',
                                cls:['infoPanel'],
                                
                                layout: 'fit',
                                flex: 9,                                
                                id: 'casecontentpanel',
                                items: [
                                	{
                                        xtype: 'panel',
                                        layout: 'fit',
                                        id: 'caseformpanel',                                        
                                    }, 
                                ]
                            }, {
                                 xtype: 'toolbar',
                                 id: 'casetoolbar',
                                 layout:{
                                   	align:'center',
                                   	pack:'right'                                     	
                                 },
                                 docked: 'bottom',
                                 items: [
                                   	{
                                       xtype: 'button',
                                       action: 'savecasedata',                   
                                       text: 'Save'
                                    }, {
                                       xtype: 'button',
                                       action: 'cancelcasedata',                    
                                       text: 'Cancel'
                                    },{
                                       xtype: 'button',
                                       action: 'exportcasedata',                    
                                       text: 'Export'
                                    }
                                    
                                ]
                            }
                        ]    
                    }
                ]
            }
        ]
    },
    
    initialize: function(){
        this.callParent(arguments);
        cfa.app.helpUrl = "Cases";
    }
});
