Ext.define('cfa.view.phone.Main', {
    extend: 'cfa.view.Main',

    requires: [
        
    ]
});
