Ext.define('cfa.model.CaseForm', {
    extend: 'Ext.data.Model',

    config: {
        fields: [
            { name: 'formName', type: 'string' }
        ]
    }
});
